"use server";

import { createClient } from "@/lib/supabase/server";

export type RentalGame = {
  id: string;
  title: string;
  platform: string;
  description?: string | null;
  cover_url?: string | null;
  price_type: "free" | "paid" | "tiered" | string;
  price_amount: number;
  total_copies: number;
  available_copies: number;
  is_active: boolean;
  created_at: string;
};

export type RentalRequest = {
  id: string;
  rental_game_id: string;
  user_id: string;
  status: string;
  shipping_address: string;
  notes: string | null;
  reserved_until: string | null;
  start_date: string | null;
  due_date: string | null;
  created_at: string;

  rental_game: {
    title: string;
    platform: string;
    cover_url: string | null;
    price_type: string;
    price_amount: number;
  } | null;

  user: {
    full_name: string;
    username: string;
    email: string;
  } | null;
};




export async function getRentalCatalog() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("rental_games")
    .select("*")
    .eq("is_active", true)
    .gt("available_copies", 0)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []) as RentalGame[];
}


export async function getRentalGame(id: string) {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("rental_games")
    .select("*")
    .eq("id", id)
    .maybeSingle();

  if (error) throw error;
  return data as RentalGame | null;
}

export async function createRentalRequest(gameId: string, shippingAddress: string, notes?: string) {
  const supabase = await createClient();

  const { data, error } = await supabase.rpc("create_rental_request", {
    p_rental_game_id: gameId,          // ✅ match function param in SQL
    p_shipping_address: shippingAddress,
    p_notes: notes ?? null,
  });

  if (error) throw error;
  return data as string;
}


/* ---------------- Admin ---------------- */

export async function adminGetRentalRequests() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("rental_requests")
    .select(`
      id,
      rental_game_id,
      user_id,
      status,
      shipping_address,
      notes,
      reserved_until,
      start_date,
      due_date,
      created_at,

      rental_game:rental_games!rental_requests_rental_game_id_fkey (
        title,
        platform,
        cover_url,
        price_type,
        price_amount
      ),

      user:users!rental_requests_user_id_fkey (
        full_name,
        username,
        email
      )
    `)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("❌ adminGetRentalRequests error:", error);
    throw error;
  }

  return (data ?? []) as unknown as RentalRequest[];
}


export async function adminUpdateRentalStatus(requestId: string, status: string) {
  const supabase = await createClient();

  const { error } = await supabase.rpc("admin_update_rental_status", {
    p_request_id: requestId,
    p_status: status,
  });

  if (error) throw error;

  return true;
}

