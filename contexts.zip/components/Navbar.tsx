"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/auth-context";
import {
  LogIn,
  BookCopy,
  MessageCircle,
  LayoutDashboard,
  Gamepad2,
} from "lucide-react";
import { createBrowserClient } from "@supabase/ssr";

const SIGNIN_PATH = "/auth";

export default function Navbar() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const supabase = useRef(
    createBrowserClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    )
  ).current;

  const [mounted, setMounted] = useState(false);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const subscribedRef = useRef(false);

  const isAdmin =
    (user as any)?.is_admin === true ||
    (user as any)?.user_metadata?.is_admin === true ||
    (user as any)?.profile?.is_admin === true;

  // ✅ Wait for hydration
  useEffect(() => setMounted(true), []);

  // 🔁 Poll unread chat count
  useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      return;
    }

    let cancelled = false;
    async function fetchUnread() {
      try {
        const res = await fetch("/api/unread-count");
        if (!res.ok) return;
        const data = await res.json();
        if (!cancelled) setUnreadCount(data.count ?? 0);
      } catch (err) {
        console.error("❌ Failed to fetch unread count:", err);
      }
    }

    fetchUnread();
    const id = setInterval(fetchUnread, 8000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [user]);

  if (!mounted)
    return <nav className="h-[60px] w-full bg-navbar border-b border-border" />;

  return (
    <nav className="bg-navbar text-white border-b border-border flex items-center justify-between px-5 sm:px-10 py-3 sticky top-0 z-50 shadow-md">
      <Link href="/" className="flex items-center gap-2">
        <Image
          src="/logo.png"
          alt="Checkpoint Logo"
          width={140}
          height={40}
          priority
        />
      </Link>

      <div className="flex items-center gap-3">
        {/* Not logged in */}
        {!loading && !user && (
          <Link
            href={SIGNIN_PATH}
            className="p-2 hover:bg-[#C6FF00]/20 rounded-full text-[#C6FF00] transition"
          >
            <LogIn size={22} />
          </Link>
        )}

        {/* Logged in */}
        {!loading && user && (
          <>
            {isAdmin && (
              <Link
                href="/admin"
                className="relative hidden sm:inline-flex items-center gap-1 rounded-full border border-lime-400/70 bg-black/40 px-3 py-1.5 text-xs font-semibold text-lime-300 hover:bg-lime-400/10 transition"
              >
                <LayoutDashboard size={18} />
                <span>Dashboard</span>
              </Link>
            )}

            <Link
              href="/matches"
              className="p-2 hover:bg-white/10 rounded-full transition"
            >
              <BookCopy className="transform rotate-180" size={22} />
            </Link>

            {/* 🎮 My Rentals — notification bubble removed */}
            <Link
              href="/profile/my-rentals"
              className="p-2 hover:bg-white/10 rounded-full transition"
            >
              <Gamepad2 size={22} />
            </Link>

            {/* 💬 Messages — unread badge stays */}
            <Link
              href="/chat"
              className="relative p-2 hover:bg-white/10 rounded-full transition"
            >
              <MessageCircle size={22} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-[11px] font-bold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </Link>

            {/* 👤 Profile Avatar */}
            <button
              onClick={() => router.push("/profile")}
              className="w-10 h-10 rounded-full border border-white/30 overflow-hidden hover:border-white/60 transition"
            >
              <Image
                src={user.avatar_url || "/default.jpg"}
                alt={user.full_name || "Profile avatar"}
                width={40}
                height={40}
                className="object-cover w-full h-full rounded-full"
              />
            </button>
          </>
        )}
      </div>
    </nav>
  );
}
