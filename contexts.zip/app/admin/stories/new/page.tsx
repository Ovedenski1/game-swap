// app/admin/stories/new/page.tsx
import StoryEditor from "@/components/StoryEditor";

export default function NewStoryPage() {
  return <StoryEditor mode="create" />;
}
